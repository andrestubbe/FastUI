package fastui.layout;

import fastui.behaviour.Behaviour;
import fastui.component.Component;
import fastui.component.Panel;

import java.awt.*;

/**
 * A reusable three-pane workspace layout consisting of a left panel, center panel,
 * and right panel separated by resizable drag handles.
 */
public class WorkspaceLayout extends Component {
    private final Component leftPanel;
    private final Component centerPanel;
    private final Component rightPanel;

    private final Panel leftResizeHandle;
    private final Panel leftResizeLine;
    private final Panel rightResizeHandle;
    private final Panel rightResizeLine;

    private int leftPanelWidth = 250;
    private int rightPanelWidth = 250;
    private boolean showLeftPanel = false;
    private boolean showRightPanel = false;

    private int leftMinW = 180;
    private int leftMaxW = 450;
    private int leftSnapClose = 130;

    private int rightMinW = 180;
    private int rightMaxW = 450;
    private int rightSnapClose = 130;

    private float lastW, lastH;

    public WorkspaceLayout(Component leftPanel, Component centerPanel, Component rightPanel) {
        this.leftPanel = leftPanel;
        this.centerPanel = centerPanel;
        this.rightPanel = rightPanel;

        // Add child components
        this.add(leftPanel);
        this.add(centerPanel);
        this.add(rightPanel);

        // Initialize left resize handle
        this.leftResizeHandle = new Panel(null);
        this.leftResizeLine = new Panel(new Color(64, 64, 64));
        this.leftResizeLine.setVisible(false);
        this.leftResizeHandle.add(leftResizeLine);
        this.add(leftResizeHandle);

        this.leftResizeHandle.addBehavior(new Behaviour() {
            private float dragStartWidth;
            private float dragStartX;

            @Override
            public void onMousePressed(Component target, float mx, float my) {
                dragStartWidth = leftPanelWidth;
                dragStartX = mx;
                leftResizeLine.setVisible(true);
            }

            @Override
            public void onMouseDragged(Component target, float mx, float my) {
                float deltaX = mx - dragStartX;
                float newW = dragStartWidth + deltaX;

                if (newW < leftSnapClose) {
                    showLeftPanel = false;
                    leftPanel.setVisible(false);
                    leftResizeHandle.setVisible(false);
                    leftResizeLine.setVisible(false);
                    if (target.getRoot() != null) {
                        target.getRoot().setCursor(Cursor.getDefaultCursor());
                    }
                } else {
                    showLeftPanel = true;
                    leftPanel.setVisible(true);
                    leftResizeHandle.setVisible(true);
                    leftResizeLine.setVisible(true);
                    leftPanelWidth = Math.min(leftMaxW, (int) newW);
                }
                layout();
            }

            @Override
            public void onMouseEnter(Component target) {
                leftResizeLine.setVisible(true);
                if (target.getRoot() != null) {
                    target.getRoot().setCursor(Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR));
                }
            }

            @Override
            public void onMouseExit(Component target) {
                leftResizeLine.setVisible(false);
                if (target.getRoot() != null) {
                    target.getRoot().setCursor(Cursor.getDefaultCursor());
                }
            }
        });

        // Initialize right resize handle
        this.rightResizeHandle = new Panel(null);
        this.rightResizeLine = new Panel(new Color(64, 64, 64));
        this.rightResizeLine.setVisible(false);
        this.rightResizeHandle.add(rightResizeLine);
        this.add(rightResizeHandle);

        this.rightResizeHandle.addBehavior(new Behaviour() {
            private float dragStartWidth;
            private float dragStartX;

            @Override
            public void onMousePressed(Component target, float mx, float my) {
                dragStartWidth = rightPanelWidth;
                dragStartX = mx;
                rightResizeLine.setVisible(true);
            }

            @Override
            public void onMouseDragged(Component target, float mx, float my) {
                float deltaX = mx - dragStartX;
                float newW = dragStartWidth - deltaX;

                if (newW < rightSnapClose) {
                    showRightPanel = false;
                    rightPanel.setVisible(false);
                    rightResizeHandle.setVisible(false);
                    rightResizeLine.setVisible(false);
                    if (target.getRoot() != null) {
                        target.getRoot().setCursor(Cursor.getDefaultCursor());
                    }
                } else {
                    showRightPanel = true;
                    rightPanel.setVisible(true);
                    rightResizeHandle.setVisible(true);
                    rightResizeLine.setVisible(true);
                    rightPanelWidth = Math.min(rightMaxW, (int) newW);
                }
                layout();
            }

            @Override
            public void onMouseEnter(Component target) {
                rightResizeLine.setVisible(true);
                if (target.getRoot() != null) {
                    target.getRoot().setCursor(Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR));
                }
            }

            @Override
            public void onMouseExit(Component target) {
                rightResizeLine.setVisible(false);
                if (target.getRoot() != null) {
                    target.getRoot().setCursor(Cursor.getDefaultCursor());
                }
            }
        });
    }

    public void setLeftPanelLimits(int minW, int maxW, int snapClose) {
        this.leftMinW = minW;
        this.leftMaxW = maxW;
        this.leftSnapClose = snapClose;
    }

    public void setRightPanelLimits(int minW, int maxW, int snapClose) {
        this.rightMinW = minW;
        this.rightMaxW = maxW;
        this.rightSnapClose = snapClose;
    }

    public int getLeftPanelWidth() {
        return leftPanelWidth;
    }

    public int getRightPanelWidth() {
        return rightPanelWidth;
    }

    public boolean isShowLeftPanel() {
        return showLeftPanel;
    }

    public boolean isShowRightPanel() {
        return showRightPanel;
    }

    public void setShowLeftPanel(boolean show) {
        this.showLeftPanel = show;
        this.leftPanel.setVisible(show);
        this.leftResizeHandle.setVisible(show);
        layout();
    }

    public void setShowRightPanel(boolean show) {
        this.showRightPanel = show;
        this.rightPanel.setVisible(show);
        this.rightResizeHandle.setVisible(show);
        layout();
    }

    public void setResizeColors(Color color) {
        this.leftResizeLine.setBackgroundColor(color);
        this.rightResizeLine.setBackgroundColor(color);
    }

    @Override
    public void setBounds(float x, float y, float width, float height) {
        super.setBounds(x, y, width, height);
        this.lastW = width;
        this.lastH = height;
        layout();
    }

    private void layout() {
        if (lastW <= 0 || lastH <= 0) return;

        float width = lastW;
        float height = lastH;

        float leftX = 0;
        if (showLeftPanel) {
            int leftPanelW = Math.max(leftMinW, leftPanelWidth);
            int leftPanelX = Math.min(0, leftPanelWidth - leftMinW);
            this.leftPanel.setBounds(leftPanelX, 0, leftPanelW, height);
            leftX = Math.max(0, leftPanelWidth);

            this.leftResizeHandle.setBounds(leftPanelWidth - 4, 0, 8, height);
            this.leftResizeLine.setBounds(4, 0, 1, height);
            this.leftResizeHandle.setVisible(true);
        } else {
            this.leftResizeHandle.setVisible(false);
        }

        float rightX = width;
        if (showRightPanel) {
            int rightPanelW = Math.max(rightMinW, rightPanelWidth);
            int rightPanelX = (int) (width - rightPanelW + Math.max(0, rightMinW - rightPanelWidth));
            this.rightPanel.setBounds(rightPanelX, 0, rightPanelW, height);
            rightX = width - Math.max(0, rightPanelWidth);

            this.rightResizeHandle.setBounds(width - rightPanelWidth - 4, 0, 8, height);
            this.rightResizeLine.setBounds(4, 0, 1, height);
            this.rightResizeHandle.setVisible(true);
        } else {
            this.rightResizeHandle.setVisible(false);
        }

        float centerWidth = rightX - leftX;
        this.centerPanel.setBounds(leftX, 0, centerWidth, height);

        if (getRoot() != null) {
            getRoot().repaint();
        }
    }

    @Override
    public void onRender(Graphics2D g) {
        // WorkspaceLayout has no direct visual elements to render itself
    }
}
